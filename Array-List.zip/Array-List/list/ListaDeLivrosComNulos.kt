fun main() {
    listaLivrosComNulos.imprimeComMarcadores()
}